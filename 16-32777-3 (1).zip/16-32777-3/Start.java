import java.lang.*;
public class Start{
	public static void main(String args[])
	{
		 Rectangle r =new  Rectangle(12,1);
		 r.setLength(3);
		 r.setWidth(2);
		System.out.print("LENGTH:"+r.getLength());
				System.out.print("WIDTH:"+r.getWidth());
								System.out.print("AREA:"+r.getArea());
				
		 Triangle t =new Triangle(2,3);
		 t.setHeight(1);
		 t.setBase(2);
		System.out.print("HEIGHT:"+t.getHeight()); 
		 System.out.print("BASE:"+t.getBase());
		 System.out.print("AREA:"+t.getArea());
		

		 Circle c =new Circle();
		 c.setRadius(3);
		
		 System.out.print("RADIUS:"+c.getRadius());
		 System.out.print("AREA:"+c.getArea());
		
		Square s =new Square();
		
		s.setSide(3);
		
		System.out.print("SIDE:"+s.getSide());
			 System.out.print("AREA:"+s.getArea());
		
	}
}